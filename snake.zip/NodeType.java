
public enum NodeType {

	    empty,
	    apple,
	    obstacle,
	    snake
	    
}
