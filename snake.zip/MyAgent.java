
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.*;
import java.util.Random;

import za.ac.wits.snake.DevelopmentAgent;

public class MyAgent extends DevelopmentAgent {

	static int snakeHeadx=0;
	static int snakeHeady=0;
	static int snakeDirx=0;
	static int snakeDiry=0;
	static int appleDist=0;
	static int applex=0;
	static int appley=0;
	static int[][] DIRS= {{1,0},{0,-1},{-1,0},{0,1}};
    static int[] row= {1,0,-1,0};
    static int[] col= {0,-1,0,1};
	
	public int heuristic(Node start, Node end)
	{
		return Math.abs(start.x-end.x) + Math.abs(start.y+end.y);
	}
	
	public int NeighbourDist(Node start, Node end)
	{
		return heuristic(start,end);
	}
	
	public ArrayList<Node> Neighbours(Node id)
	{
		ArrayList<Node> neighbour = new ArrayList<Node>();
		 for (int i = 0; i < 4; i++) 
		 {
			int x= id.x+row[i];
			int y=id.y + col[i];
			if(id.type==null||id.type==NodeType.empty)
			{
				neighbour.add(new Node(x,y,id));
			}
			
		 }
		
		 return neighbour;
	}
			
			
	
    public Node findPath(Node start, Node end)
    {
    	
    	//Dictionary<Location, Location> cameFrom = new Hashtable<Location, Location>();
    	NodeCompare n = new NodeCompare();
    	
    	PriorityQueue<Node> openQueue = new PriorityQueue<>(n);
    	PriorityQueue<Node> closeQueue = new PriorityQueue<>(n);
    	openQueue.add(start);
    	//Stack<Node> path = new Stack<>();

  	
    	while(openQueue.size()>0)
    	{
    		
    		Node curr = openQueue.poll();
    		curr.visited=true;
    		closeQueue.add(curr);
    		
    		if(curr.equals(end))
    		{
    			return curr;
    		}
    		
    		ArrayList<Node> neighbours = Neighbours(curr);
    		for(Node neighbour : neighbours)
    		{
    			if(neighbour.type!=NodeType.empty && neighbour.type!=NodeType.apple && closeQueue.contains(neighbour))
    			{
    				continue;
    			}
    			
    			if(neighbour.equals(end))
    			{
    				return neighbour;
    			}
    			
    			
    			int cost= curr.getg()+heuristic(curr,end);
    			if(cost<neighbour.getg() || !openQueue.contains(neighbour))
    			{
    				neighbour.setg(cost);
    				neighbour.seth(heuristic(curr,end));
    				neighbour.parent=curr;
    				neighbour.setf();
    			}
	
    			if(!openQueue.contains(neighbours))
        		{
    				openQueue.add(neighbour);
        		}
    			
    		}

    		
    		closeQueue.add(curr);
    		
    		
    	}
    	return null;
    }
    

    
    
    
    public void printPath(Node node)
    {
    	
    	Node current=node;
    	Node parent=null;

    	
    	if(current.parent!=null)
    	{
    		parent=current.parent;
    	}
    	
    	while(current.parent.parent!=null)
    	{
    		current=parent;
    		parent=current.parent;
    	}

    	moveTo(parent,current);
    	
    	
    	
    }
    
    void moveTo(Node current, Node next) {
        if (current.x == next.x) {
            if (current.y < next.y) {
                System.out.println(1);
                System.err.println(1);
            } else {
                System.out.println(0);
                System.err.println(0);
            }
        } else {
            if (current.x < next.x) {
                System.out.println(3);
                System.err.println(3);
            } else {
            	System.out.println(2);
            	System.err.println(2);
            }
        }
    }
    
    public static boolean isValid(int x, int y)
	{
		if(x>=0 && x<49 && y>=0 && y<49)
		{
			return true;
		}
		
		return false; 
	}
    
    public void plotSnakes(Node gameMap[][],int headx, int heady, int directionx, int directiony)
    {
    	if(directionx>headx && directiony==heady)
		{
			for(int l=headx; l<=directionx; l++)
			{
				gameMap[l][heady].type=NodeType.snake;
			}
		}
		else if(directionx>headx && directiony==heady)
		{
			for(int l=directionx; l<=headx; l++)
			{
				gameMap[l][heady].type=NodeType.snake;
			}
		}
		else if(headx==directionx && directiony>heady)
		{
			for(int l=heady; l<=directiony; l++)
			{
				gameMap[headx][l].type=NodeType.snake;
			}
		}
		else
		{
			for(int l=directiony; l<=heady; l++)
			{
				gameMap[headx][l].type=NodeType.snake;
			}
		}
    }
    
    public static void main(String args[]) throws IOException {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);
            while (true) {
                String line = br.readLine();
                Node[][] gameMap = new Node[50][50];
                for (int i = 0; i < gameMap.length; i++) {
                	for (int j = 0; j < gameMap.length; j++) {
						gameMap[i][j]=new Node(i,j,null);
					}
				}
                if (line.contains("Game Over")) {
                    break;        
                }
                String apple1 = line;
                String[] applePos=apple1.split(" ");
                applex=Integer.parseInt(applePos[0]);
                appley=Integer.parseInt(applePos[1]);
                gameMap[applex][appley].type=NodeType.apple;
                //do stuff with apple
                int nObstacles = 3;
                for (int obstacle = 0; obstacle < nObstacles; obstacle++) {
                    String obs = br.readLine();
                    /// do something with obs
                    
                    	String[] fullObs = obs.split(" ");
                    
                    for (int i = 0; i < fullObs.length; i++) {
	
                    	String[] part1= fullObs[i].split(",");
                    	int obsx=Integer.parseInt(part1[0]);
                    	int obsy=Integer.parseInt(part1[1]);
	
                    	gameMap[obsx][obsy].type=NodeType.obstacle;

                    }
                    	
                }
                int mySnakeNum = Integer.parseInt(br.readLine());
                for (int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();
                    if (i == mySnakeNum) {
                        //hey! That's me :)
                    	

                    	String[] mySnake=snakeLine.split(" ");
                    	String[] headPos=mySnake[3].split(",");
                    	String[] direction=mySnake[4].split(",");
                    	
                    	snakeDirx=Integer.parseInt(direction[0]);
                    	snakeDiry=Integer.parseInt(direction[1]);
                    	
                    	snakeHeadx=Integer.parseInt(headPos[0]);
                    	snakeHeady=Integer.parseInt(headPos[1]);

                    }
                    
                    String[] otherSnakes=snakeLine.split(" ");
                    for (int j = 3; j < otherSnakes.length-1; j++) {
                    	
                    	String[] others=otherSnakes[j].split(",");
                    	String[] direction=otherSnakes[j+1].split(",");
                    	
                    	
                    	
                    	int directionx=Integer.parseInt(direction[0]);
                    	int directiony=Integer.parseInt(direction[1]);
                    	
						int otherx=Integer.parseInt(others[0]);
						int othery=Integer.parseInt(others[1]);
						
						plotSnakes(gameMap,otherx,othery,directionx,directiony);
;
					}
                    //do stuff with snakes
                } 
                // finished reading, calculate move:
                Node start= new Node(snakeHeadx,snakeHeady,null);
                Node end= new Node(applex,appley,null);
                Node node=findPath(start,end);
            	printPath(node);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}