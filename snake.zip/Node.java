
public class Node {

	int x;
	int y;
	boolean visited;
	int h=0;//heuristic
	int g=0;//cost from current Node
	int f=0;//total cost of present node
	Node parent;
	//Node self;
	NodeType type=null;
	
	public Node(int x, int y, Node parent)
	{
		this.x=x;
		this.y=y;
		this.parent=parent;
		
	}
	
	public void seth(int h)
	{
		this.h=h;
	}

	public void setg(int g)
	{
		this.g=g;
	}
	
	public void setf()
	{
		f=h+g;
	}
	
	public int getf()
	{
		return f;
	}

	public int getg()
	{
		return g;
	}
	public int geth()
	{
		return h;
	}
	
//	@Override
//	public double compareTo(Node node1, Node node2)
//	{
//		if(node1.getf()>node2.getf())
//		{
//			return node2.getf();
//		}
//		else
//		{
//			return node1.getf();
//		}
//	}
	
}
